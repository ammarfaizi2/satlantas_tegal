<?php
require __DIR__."/LINE/config.php";
require __DIR__."/autoload.php";
LINE\Bot\Run::run();