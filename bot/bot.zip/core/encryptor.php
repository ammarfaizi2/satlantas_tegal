<?php
function tcrypt($str, $key)
{
	
}

function dcrypt($str, $key)
{
	
}