<!DOCTYPE html>
<html>
<head>
<title>Login</title>
</head>
<body>
<center>
<form method="post" action="">
<label>Username : </label><br>
<input type="text" name="username"><br><br>
<label>Password : </label><br>
<input type="password" name="password"><br><br>
<input type="submit" name="login" value="Login">
</form>
</body>
</html>