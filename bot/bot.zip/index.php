<?php
require __DIR__.'/autoload.php';
Panel\Run::run();