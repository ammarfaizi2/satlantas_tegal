<?php
require __DIR__."/Telegram/config.php";
require __DIR__."/autoload.php";
Telegram\Bot\Run::run();