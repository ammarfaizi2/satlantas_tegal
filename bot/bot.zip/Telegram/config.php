<?php
define("TOKEN", "370018113:AAEDH4y6nNGxl2qZvKhye9rqV4pZQ4LVzdE");