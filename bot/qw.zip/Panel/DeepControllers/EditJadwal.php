<?php

namespace Panel\DeepControllers;

use PDO;
use SysHandler\DB;

class EditJadwal
{
	public static function run($id)
	{
		self::__run($id);
	}

	private static function __run($id)
	{
		$st = DB::pdo()->prepare("SELECT * FROM `jadwal_sim_keliling` WHERE id_jadwal = :id LIMIT 1;");
		$exe = $st->execute(array(":id" => $id));
		if ($val = $st->fetch(PDO::FETCH_ASSOC)) {
			require __DIR__."/../../views/edit_jadwal.php";
		} else {
			header("location:?pg=jadwal_sim_keliling");
			die();
		}
	}
}