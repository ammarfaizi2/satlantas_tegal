<?php
/*define("DB_HOST", "localhost");
define("DB_USER", "tegaljat_lantas");
define("DB_PASS", "triosemut123");
define("DB_NAME", "tegaljat_lantas");*/

define("DB_HOST", "localhost");
define("DB_USER", "debian-sys-maint");
define("DB_PASS", "");
define("DB_NAME", "tegal");

/*define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "");
define("DB_NAME", "tegal");
*/