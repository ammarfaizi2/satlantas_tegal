<?php

namespace LINE\Bot;

class Run
{
	public static function run()
	{
		
	}
}